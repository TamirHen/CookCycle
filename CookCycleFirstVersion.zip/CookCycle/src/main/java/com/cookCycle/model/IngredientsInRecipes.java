package com.cookCycle.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class IngredientsInRecipes {
    @Id
    private int id;
    private Integer recipe;
    private Integer ingredient;
    private Double amount;
    private String unit;
    private String unitAndAmountString;

    protected IngredientsInRecipes() {
    }

    public IngredientsInRecipes(Integer recipe, Integer ingredient, Double amount, String unit, String unitAndAmountString) {
        this.recipe = recipe;
        this.ingredient = ingredient;
        this.amount = amount;
        this.unit = unit;
        this.unitAndAmountString = unitAndAmountString;
    }

    @Id
    @Column(name = "id")
    public int getId() {
        return id;
    }
    //Only DB Should set the id
    private void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "recipe")
    public Integer getRecipe() {
        return recipe;
    }

    public void setRecipe(Integer recipe) {
        this.recipe = recipe;
    }

    @Basic
    @Column(name = "ingredient")
    public Integer getIngredient() {
        return ingredient;
    }

    public void setIngredient(Integer ingredient) {
        this.ingredient = ingredient;
    }

    @Basic
    @Column(name = "amount")
    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @Basic
    @Column(name = "unit")
    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Basic
    @Column(name = "unitAndAmountString")
    public String getUnitAndAmountString() {
        return unitAndAmountString;
    }

    public void setUnitAndAmountString(String unitAndAmountString) {
        this.unitAndAmountString = unitAndAmountString;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        IngredientsInRecipes that = (IngredientsInRecipes) o;

        if (id != that.id) return false;
        if (recipe != null ? !recipe.equals(that.recipe) : that.recipe != null) return false;
        if (ingredient != null ? !ingredient.equals(that.ingredient) : that.ingredient != null) return false;
        if (amount != null ? !amount.equals(that.amount) : that.amount != null) return false;
        if (unit != null ? !unit.equals(that.unit) : that.unit != null) return false;
        if (unitAndAmountString != null ? !unitAndAmountString.equals(that.unitAndAmountString) : that.unitAndAmountString != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (recipe != null ? recipe.hashCode() : 0);
        result = 31 * result + (ingredient != null ? ingredient.hashCode() : 0);
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        result = 31 * result + (unit != null ? unit.hashCode() : 0);
        result = 31 * result + (unitAndAmountString != null ? unitAndAmountString.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "IngredientsInRecipes{" +
                "id=" + id +
                ", recipe=" + recipe +
                ", ingredient=" + ingredient +
                ", amount=" + amount +
                ", unit='" + unit + '\'' +
                ", unitAndAmountString='" + unitAndAmountString + '\'' +
                '}';
    }
}
